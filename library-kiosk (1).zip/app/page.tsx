"use client"

import LibraryKiosk from "../library-kiosk"

export default function Page() {
  return <LibraryKiosk />
}
