import { NextResponse } from "next/server"
import { supabase, supabaseAdmin } from "@/lib/supabase"

export async function GET() {
  try {
    // Test basic connection
    const { data: connectionTest, error: connectionError } = await supabase
      .from("books")
      .select("count", { count: "exact", head: true })

    if (connectionError) {
      return NextResponse.json(
        {
          error: "Supabase bağlantı hatası",
          details: connectionError.message,
        },
        { status: 500 },
      )
    }

    // Test admin connection
    const { data: adminTest, error: adminError } = await supabaseAdmin
      .from("categories")
      .select("count", { count: "exact", head: true })

    if (adminError) {
      return NextResponse.json(
        {
          error: "Supabase admin bağlantı hatası",
          details: adminError.message,
        },
        { status: 500 },
      )
    }

    // Get some basic stats
    const { data: bookCount } = await supabase.from("books").select("id", { count: "exact", head: true })

    const { data: categoryCount } = await supabase.from("categories").select("id", { count: "exact", head: true })

    return NextResponse.json({
      message: "Supabase bağlantısı başarılı!",
      stats: {
        totalBooks: bookCount?.length || 0,
        totalCategories: categoryCount?.length || 0,
      },
      timestamp: new Date().toISOString(),
      environment: {
        supabaseUrl: process.env.NEXT_PUBLIC_SUPABASE_URL ? "✓ Tanımlı" : "✗ Tanımsız",
        anonKey: process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY ? "✓ Tanımlı" : "✗ Tanımsız",
        serviceKey: process.env.SUPABASE_SERVICE_ROLE_KEY ? "✓ Tanımlı" : "✗ Tanımsız",
        openaiKey: process.env.OPENAI_API_KEY ? "✓ Tanımlı" : "✗ Tanımsız",
      },
    })
  } catch (error) {
    console.error("Supabase test error:", error)
    return NextResponse.json(
      {
        error: "Test sırasında hata oluştu",
        details: error.message,
      },
      { status: 500 },
    )
  }
}
