import { type NextRequest, NextResponse } from "next/server"
import { supabaseAdmin } from "@/lib/supabase"
import { generateText } from "ai"
import { openai } from "@ai-sdk/openai"

// Fallback mock data for when database isn't set up yet
const mockBooks = [
  {
    id: 1,
    title: "1984",
    author: "George Orwell",
    genre: "Distopya",
    description: "Distopik gelecek kurgusu",
    color_gradient: "from-red-600 to-red-800",
    available_copies: 1,
  },
  {
    id: 2,
    title: "Pride and Prejudice",
    author: "Jane Austen",
    genre: "Romantik Klasik",
    description: "Klasik romantik roman",
    color_gradient: "from-pink-600 to-pink-800",
    available_copies: 1,
  },
  {
    id: 3,
    title: "The Lord of the Rings",
    author: "J. R. R. Tolkien",
    genre: "Epik Fantastik",
    description: "Büyük fantastik macera",
    color_gradient: "from-purple-600 to-purple-800",
    available_copies: 1,
  },
]

const mockFailureMessages = [
  "Üzgünüm, benzer türde kitap önerisi bulamadım; farklı bir favori deneyebilir misin?",
  "Şu an elimde bu kitaba yakın öneri yok; başka bir kitap adı girelim mi?",
  "Aradığın tarza uygun eser bulamadım; başka bir başlık yaz lütfen.",
]

const OPENAI_API_KEY =
  process.env.OPENAI_API_KEY ||
  "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"

async function getRandomFailureMessage() {
  try {
    const { data: messages, error } = await supabaseAdmin.from("failure_messages").select("message")

    if (error || !messages || messages.length === 0) {
      // Fallback to mock messages
      const randomIndex = Math.floor(Math.random() * mockFailureMessages.length)
      return mockFailureMessages[randomIndex]
    }

    const randomIndex = Math.floor(Math.random() * messages.length)
    return messages[randomIndex].message
  } catch (error) {
    console.error("Error getting failure message:", error)
    const randomIndex = Math.floor(Math.random() * mockFailureMessages.length)
    return mockFailureMessages[randomIndex]
  }
}

export async function POST(request: NextRequest) {
  try {
    const { userInput, excludeIds = [] } = await request.json()

    if (!userInput || userInput.trim().length === 0) {
      return NextResponse.json({ error: "Kullanıcı girişi gerekli" }, { status: 400 })
    }

    // Check if database is set up by trying to get books
    let allBooks
    let usingDatabase = false

    try {
      const { data: dbBooks, error: booksError } = await supabaseAdmin
        .from("books")
        .select("*")
        .eq("available_copies", 1)
        .not("id", "in", `(${excludeIds.join(",") || "0"})`)

      if (booksError) {
        console.error("Books fetch error:", booksError.message)
        allBooks = mockBooks.filter((book) => !excludeIds.includes(book.id))
      } else {
        allBooks = dbBooks || []
        usingDatabase = true
      }
    } catch (dbError) {
      console.error("Database error:", dbError)
      allBooks = mockBooks.filter((book) => !excludeIds.includes(book.id))
    }

    if (!allBooks || allBooks.length === 0) {
      console.log("No books found, using mock data")
      allBooks = mockBooks.filter((book) => !excludeIds.includes(book.id))
      usingDatabase = false
    }

    // If no books available, return failure message
    if (allBooks.length === 0) {
      const failureMessage = await getRandomFailureMessage()
      return NextResponse.json({
        error: failureMessage,
        books: [],
        source: "no_books_available",
      })
    }

    try {
      // Try to use OpenAI for recommendations
      const bookList = allBooks
        .map((book) => `${book.id}: "${book.title}" - ${book.author} (${book.genre || book.category})`)
        .join("\n")

      const prompt = `
Kullanıcı şu kitapları beğeniyor: "${userInput}"

Aşağıdaki kitap listesinden kullanıcının beğenisine uygun 3 kitap öner. 
Sadece kitap ID'lerini virgülle ayırarak ver (örnek: 1,5,9):

${bookList}

Önerilen kitap ID'leri:`

      const { text } = await generateText({
        model: openai("gpt-4o-mini"),
        prompt,
        maxTokens: 100,
      })

      // OpenAI'dan gelen ID'leri parse et
      const recommendedIds = text
        .trim()
        .split(",")
        .map((id) => Number.parseInt(id.trim()))
        .filter((id) => !isNaN(id))
        .slice(0, 3)

      if (recommendedIds.length === 0) {
        // If AI couldn't find recommendations, return failure message
        const failureMessage = await getRandomFailureMessage()
        return NextResponse.json({
          error: failureMessage,
          books: [],
          source: "ai_no_recommendations",
        })
      }

      // Önerilen kitapları al
      const recommendedBooks = allBooks.filter((book) => recommendedIds.includes(book.id)).slice(0, 3)

      // If not enough books found, return failure message
      if (recommendedBooks.length === 0) {
        const failureMessage = await getRandomFailureMessage()
        return NextResponse.json({
          error: failureMessage,
          books: [],
          source: "no_matching_books",
        })
      }

      // Eğer yeterli kitap yoksa, eksik olanları rastgele ekle
      if (recommendedBooks.length < 3) {
        const remainingBooks = allBooks.filter((book) => !recommendedIds.includes(book.id))
        const shuffled = remainingBooks.sort(() => 0.5 - Math.random())
        const needed = 3 - recommendedBooks.length
        recommendedBooks.push(...shuffled.slice(0, needed))
      }

      // Try to save recommendation to database if it exists
      if (usingDatabase) {
        try {
          await supabaseAdmin.from("book_recommendations").insert({
            user_input: userInput,
            recommended_books: recommendedBooks,
          })
        } catch (saveError) {
          console.error("Save recommendation error:", saveError)
          // Continue even if save fails
        }
      }

      return NextResponse.json({
        books: recommendedBooks,
        source: usingDatabase ? "database_ai" : "mock_ai",
      })
    } catch (aiError) {
      console.error("AI recommendation error:", aiError)

      // If AI fails, return failure message instead of random books
      const failureMessage = await getRandomFailureMessage()
      return NextResponse.json({
        error: failureMessage,
        books: [],
        source: "ai_error",
      })
    }
  } catch (error) {
    console.error("Recommendation error:", error)

    // Return failure message in case of any error
    const failureMessage = await getRandomFailureMessage()
    return NextResponse.json({
      error: failureMessage,
      books: [],
      source: "general_error",
    })
  }
}
