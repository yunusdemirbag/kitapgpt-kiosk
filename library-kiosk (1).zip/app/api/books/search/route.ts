import { type NextRequest, NextResponse } from "next/server"
import { supabase } from "@/lib/supabase"

// Updated mock data with new structure
const mockBooks = [
  {
    id: 1,
    title: "1984",
    author: "George Orwell",
    genre: "Distopya",
    description: "Distopik gelecek kurgusu",
    color_gradient: "from-red-600 to-red-800",
    available_copies: 1,
  },
  {
    id: 2,
    title: "Pride and Prejudice",
    author: "Jane Austen",
    genre: "Romantik Klasik",
    description: "Klasik romantik roman",
    color_gradient: "from-pink-600 to-pink-800",
    available_copies: 1,
  },
  {
    id: 3,
    title: "The Lord of the Rings",
    author: "J. R. R. Tolkien",
    genre: "Epik Fantastik",
    description: "Büyük fantastik macera",
    color_gradient: "from-purple-600 to-purple-800",
    available_copies: 1,
  },
  {
    id: 4,
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    genre: "Modern Klasik",
    description: "Modern klasik roman",
    color_gradient: "from-blue-600 to-blue-800",
    available_copies: 1,
  },
  {
    id: 5,
    title: "Harry Potter and the Sorcerer's Stone",
    author: "J. K. Rowling",
    genre: "Fantastik",
    description: "Büyücülük dünyası",
    color_gradient: "from-violet-600 to-violet-800",
    available_copies: 1,
  },
]

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const query = searchParams.get("q")
    const category = searchParams.get("category")
    const limit = Number.parseInt(searchParams.get("limit") || "10")

    try {
      let supabaseQuery = supabase
        .from("books")
        .select("*")
        .eq("available_copies", 1) // Sadece mevcut kitaplar
        .limit(limit)

      if (query) {
        // Full-text search kullan
        supabaseQuery = supabaseQuery.or(
          `title.ilike.%${query}%,author.ilike.%${query}%,genre.ilike.%${query}%,description.ilike.%${query}%`,
        )
      }

      if (category) {
        supabaseQuery = supabaseQuery.eq("genre", category)
      }

      const { data: books, error } = await supabaseQuery

      if (error) {
        console.error("Supabase error:", error.message)
        // If database error, filter mock data
        let filteredBooks = mockBooks

        if (query) {
          const lowerQuery = query.toLowerCase()
          filteredBooks = mockBooks.filter(
            (book) =>
              book.title.toLowerCase().includes(lowerQuery) ||
              book.author.toLowerCase().includes(lowerQuery) ||
              book.genre.toLowerCase().includes(lowerQuery) ||
              (book.description && book.description.toLowerCase().includes(lowerQuery)),
          )
        }

        if (category) {
          filteredBooks = filteredBooks.filter((book) => book.genre === category)
        }

        return NextResponse.json({ books: filteredBooks.slice(0, limit) })
      }

      return NextResponse.json({ books: books || [] })
    } catch (dbError) {
      console.error("Database error:", dbError)
      // Return mock data with filtering
      let filteredBooks = mockBooks

      if (query) {
        const lowerQuery = query.toLowerCase()
        filteredBooks = mockBooks.filter(
          (book) =>
            book.title.toLowerCase().includes(lowerQuery) ||
            book.author.toLowerCase().includes(lowerQuery) ||
            book.genre.toLowerCase().includes(lowerQuery) ||
            (book.description && book.description.toLowerCase().includes(lowerQuery)),
        )
      }

      if (category) {
        filteredBooks = filteredBooks.filter((book) => book.genre === category)
      }

      return NextResponse.json({ books: filteredBooks.slice(0, limit) })
    }
  } catch (error) {
    console.error("Search error:", error)
    return NextResponse.json({ books: mockBooks.slice(0, 5) })
  }
}
